#!/bin/bash
export SUDO_ASKPASS="./gui/askpass.sh"
zenity --entry --title="What url are you downloading from?" > url
zenity --entry --title="What options would you like to apply?" > option

wget $(grep -vE "^\s*#" option  | tr "\n" " ") $(grep -vE "^\s*#" url  | tr "\n" " ") | 
zenity --progress \
  --title="WGET" \
  --text="Downloading..." \
  --percentage=0 \
  --pulsate
 
