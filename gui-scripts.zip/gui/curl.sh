#!/bin/bash
export SUDO_ASKPASS="./gui/askpass.sh"
zenity --entry --title="What url?" > url
zenity --entry --title="What options would you like to apply?" > option
curl $(grep -vE "^\s*#" option  | tr "\n" " ") $(grep -vE "^\s*#" url  | tr "\n" " ")
