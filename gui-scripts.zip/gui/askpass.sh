#!/bin/bash
zenity --password --title=SUDO
