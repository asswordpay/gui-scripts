#!/bin/bash
export SUDO_ASKPASS="./gui/askpass.sh"

CURRENT_CHOICE=`zenity --list \
  --title="Apt Option" \
  --column="Option" \
    Install \
    Remove \
    Update \
    Upgrade \
    Autoremove \
    Search `
            if [ "$CURRENT_CHOICE" = "Install" ]; then
            zenity --entry --title="Please enter the apt package(s) you would like to install." > package
            sudo -A apt install -y $(grep -vE "^\s*#" package  | tr "\n" " ")   
            fi
            if [ "$CURRENT_CHOICE" = "Remove" ]; then
            zenity --entry --title="Please enter the apt package(s) you would like to remove." > package
            sudo -A apt remove -y $(grep -vE "^\s*#" package  | tr "\n" " ")   
            fi
            if [ "$CURRENT_CHOICE" = "Update" ]; then
            sudo -A apt update -y   
            fi
            if [ "$CURRENT_CHOICE" = "Upgrade" ]; then
            sudo -A apt upgrade -y  
            fi
            if [ "$CURRENT_CHOICE" = "Autoremove" ]; then
            sudo -A apt autoremove -y
            fi
            if [ "$CURRENT_CHOICE" = "Search" ]; then
            zenity --entry --title="Please enter the Search terms" > package
            sudo -A apt search $(grep -vE "^\s*#" package  | tr "\n" " ")   
            fi
